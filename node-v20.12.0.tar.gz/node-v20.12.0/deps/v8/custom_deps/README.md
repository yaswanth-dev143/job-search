Common directory for custom dependencies pulled in via .gclient custom_deps.
All subdirectories are ignored by git by default.